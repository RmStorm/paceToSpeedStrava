# paceToSpeedStrava
Converts paces in min/km to speeds in km/h

**This add-on injects JavaScript into web pages.**

## What it does

This extension just includes:

* a content script, "paceToSpeedStrava.js", that is injected into any pages
under "strava.com/" or any of its subdomains

The content script changes paces to speed in parts of the document.body.